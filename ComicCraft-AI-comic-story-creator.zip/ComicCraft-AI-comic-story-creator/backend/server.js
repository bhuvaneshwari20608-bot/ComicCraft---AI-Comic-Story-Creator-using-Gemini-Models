import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { GoogleGenerativeAI } from "@google/generative-ai";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;
const MODEL = process.env.GEMINI_MODEL || "gemini-2.0-flash";

app.use(cors());
app.use(express.json({ limit: "1mb" }));

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
app.use(express.static(path.join(__dirname, "../frontend")));

function cleanJson(text) {
  return text
    .replace(/^```json\s*/i, "")
    .replace(/^```\s*/i, "")
    .replace(/\s*```$/i, "")
    .trim();
}

function buildPrompt({ idea, genre, characters, panels }) {
  return `
You are ComicCraft, an expert comic writer and storyboard artist.

Create a complete ${panels}-panel comic from the information below.

Story idea:
${idea}

Genre:
${genre}

Characters:
${characters || "Create suitable characters based on the story idea."}

Return ONLY valid JSON. Do not use Markdown and do not wrap it in code fences.

Use exactly this schema:
{
  "title": "string",
  "logline": "string",
  "style": "string",
  "characters": [
    {
      "name": "string",
      "description": "string"
    }
  ],
  "panels": [
    {
      "panel": 1,
      "scene": "string",
      "action": "string",
      "dialogue": [
        {
          "speaker": "string",
          "line": "string"
        }
      ],
      "caption": "string",
      "image_prompt": "string"
    }
  ]
}

Rules:
- Create exactly ${panels} panels.
- Keep character names consistent.
- Make the story have a beginning, development, and ending.
- Dialogue should be short and natural.
- image_prompt should describe the visual composition for an AI image generator.
- Avoid copyrighted characters and existing franchises.
`;
}

app.post("/api/generate-comic", async (req, res) => {
  try {
    const { idea, genre, characters, panels } = req.body;

    if (!process.env.GEMINI_API_KEY) {
      return res.status(500).json({
        error: "GEMINI_API_KEY is not configured. Add it to backend/.env."
      });
    }

    if (!idea || !idea.trim()) {
      return res.status(400).json({ error: "Please enter a story idea." });
    }

    const panelCount = Math.min(Math.max(Number(panels) || 6, 3), 12);

    const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
    const model = genAI.getGenerativeModel({
      model: MODEL,
      generationConfig: {
        temperature: 0.8,
        responseMimeType: "application/json"
      }
    });

    const result = await model.generateContent(
      buildPrompt({
        idea: idea.trim(),
        genre: genre || "Adventure",
        characters: characters || "",
        panels: panelCount
      })
    );

    const raw = result.response.text();
    const comic = JSON.parse(cleanJson(raw));

    if (!comic.panels || comic.panels.length !== panelCount) {
      return res.status(502).json({
        error: "Gemini returned an unexpected panel count. Please try again."
      });
    }

    res.json(comic);
  } catch (error) {
    console.error(error);
    res.status(500).json({
      error: error.message || "Unable to generate the comic."
    });
  }
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "../frontend/index.html"));
});

app.listen(PORT, () => {
  console.log(`ComicCraft running at http://localhost:${PORT}`);
});
