# ComicCraft – AI Comic Story Creator using Gemini Models

ComicCraft is a simple full-stack web application that turns a user's story idea into a comic storyboard using Google's Gemini API.

## Features
- Enter a story idea, genre, characters, and number of panels.
- Generate a structured comic script with Gemini.
- Display panels with scene descriptions, dialogue, captions, and image prompts.
- Download the generated comic script as a JSON file.
- Clean responsive UI.
- API key stays on the server.

## Project structure

```text
ComicCraft-AI-comic-story-creator/
├── backend/
│   ├── server.js
│   ├── package.json
│   └── .env.example
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── app.js
└── README.md
```

## Requirements
- Node.js 18+
- A Gemini API key

## Setup

### 1. Open the backend folder

```bash
cd backend
npm install
```

### 2. Create your environment file

Copy `.env.example` to `.env` and put your Gemini API key in it:

```env
GEMINI_API_KEY=your_api_key_here
PORT=5000
```

### 3. Start the server

```bash
npm start
```

Then open:

```text
http://localhost:5000
```

## API

`POST /api/generate-comic`

Example request:

```json
{
  "idea": "A college student discovers a mysterious old camera.",
  "genre": "Mystery",
  "characters": "Ananya, a curious college student; Ravi, her funny friend",
  "panels": 6
}
```

The backend asks Gemini for a strict JSON comic structure and returns the parsed result.

## Notes
- Do not commit `.env` or your API key to GitHub.
- Gemini model names can change over time. The backend uses a configurable model through `GEMINI_MODEL`; update it if your Google AI account exposes a different Gemini model.
