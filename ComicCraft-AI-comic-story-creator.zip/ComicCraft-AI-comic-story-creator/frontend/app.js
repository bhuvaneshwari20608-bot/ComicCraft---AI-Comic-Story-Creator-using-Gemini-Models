const idea = document.getElementById("idea");
const genre = document.getElementById("genre");
const characters = document.getElementById("characters");
const panels = document.getElementById("panels");
const generateBtn = document.getElementById("generateBtn");
const status = document.getElementById("status");
const result = document.getElementById("result");
const comicTitle = document.getElementById("comicTitle");
const logline = document.getElementById("logline");
const charactersBox = document.getElementById("charactersBox");
const panelsBox = document.getElementById("panelsBox");
const downloadBtn = document.getElementById("downloadBtn");

let latestComic = null;

generateBtn.addEventListener("click", generateComic);
downloadBtn.addEventListener("click", downloadComic);

async function generateComic() {
  if (!idea.value.trim()) {
    status.textContent = "Please enter a story idea first.";
    idea.focus();
    return;
  }

  generateBtn.disabled = true;
  status.textContent = "Creating your comic story with Gemini…";
  result.classList.add("hidden");

  try {
    const response = await fetch("/api/generate-comic", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        idea: idea.value,
        genre: genre.value,
        characters: characters.value,
        panels: Number(panels.value)
      })
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || "Generation failed.");
    }

    latestComic = data;
    renderComic(data);
    status.textContent = "Comic generated successfully!";
  } catch (error) {
    status.textContent = error.message;
  } finally {
    generateBtn.disabled = false;
  }
}

function renderComic(comic) {
  comicTitle.textContent = comic.title || "Untitled Comic";
  logline.textContent = comic.logline || "";

  charactersBox.innerHTML = (comic.characters || []).map(c => `
    <div class="character">
      <strong>${escapeHtml(c.name)}</strong>
      <span>${escapeHtml(c.description)}</span>
    </div>
  `).join("");

  panelsBox.innerHTML = (comic.panels || []).map(p => {
    const dialogue = (p.dialogue || []).map(d => `
      <p><strong>${escapeHtml(d.speaker)}:</strong> ${escapeHtml(d.line)}</p>
    `).join("");

    return `
      <article class="panel">
        <div class="panel-number">Panel ${escapeHtml(p.panel)}</div>
        <div class="panel-content">
          <h3>${escapeHtml(p.scene)}</h3>
          <div class="meta"><strong>Action:</strong> ${escapeHtml(p.action)}</div>
          ${dialogue ? `<div class="dialogue">${dialogue}</div>` : ""}
          ${p.caption ? `<div class="caption">Caption: ${escapeHtml(p.caption)}</div>` : ""}
          <div class="image-prompt">
            <strong>Image prompt:</strong><br>
            ${escapeHtml(p.image_prompt)}
          </div>
        </div>
      </article>
    `;
  }).join("");

  result.classList.remove("hidden");
  result.scrollIntoView({ behavior: "smooth", block: "start" });
}

function downloadComic() {
  if (!latestComic) return;

  const blob = new Blob(
    [JSON.stringify(latestComic, null, 2)],
    { type: "application/json" }
  );

  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "comiccraft-story.json";
  a.click();
  URL.revokeObjectURL(url);
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}
